package com.example.foodtruck1;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class InsertActivity extends AppCompatActivity
{
    private ItemManager itemManager;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        itemManager = new ItemManager(this);
    }

    public void insert( View v) {
        // retrieve name and price
        EditText nameEditText =
                ( EditText) findViewById( R.id.input_name );
        EditText categoryEditText =
                ( EditText) findViewById( R.id.input_category );
        EditText priceEditText =
                ( EditText) findViewById( R.id.input_price );
        String name = nameEditText.getText( ).toString( );
        String category = categoryEditText.getText().toString();
        Double price =
                Double.parseDouble(priceEditText.getText( ).toString( ));

        // insert new Item in database
        itemManager.insert(new Item(0,category, name,price));
        Toast.makeText( this, "Item added", 	Toast.LENGTH_LONG ).show( );

        // clear data in the two EditTexts
        nameEditText.setText( "" );
        priceEditText.setText( "" );

        ArrayList<Item> items = itemManager.selectAll( );
        for( Item item : items )
            Log.w( "MainActivity", "Item = " + item.toString( ) );


    }

    public void goBack( View v )
    {
        this.finish( );
    }

}

