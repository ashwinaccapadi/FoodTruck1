package com.example.foodtruck1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ContainerActivity extends AppCompatActivity
{
    private ItemManager itemManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        itemManager = new ItemManager(this);
        updateView();
    }

    public void updateView() {
        ArrayList<Item> containers = itemManager.selectAll();
        RelativeLayout relativeLayout = new RelativeLayout(this);
        ScrollView scrollView = new ScrollView(this);

        RadioGroup group = new RadioGroup(this);
        /*group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // select from database
                Item selected = itemManager.selectById(checkedId);
                // confirm to the user
                Toast.makeText(ContainerActivity.this, selected.getName(), Toast.LENGTH_SHORT).show();
                // update screen (the list has changed)
                updateView();
            }
        });*/

        for (Item i : containers)
        {
            RadioButton rb = new RadioButton(this);
            rb.setId(i.getId());
            rb.setText(i.toString());
            // add rb to a RadioGroup group
            // in order to make them mutually exclusive
            group.addView(rb);
        }
        scrollView.addView(group);
        relativeLayout.addView(scrollView);

        Button button = new Button(this);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack(v);
            }
        });
        button.setText("BACK");

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        params.setMargins(0, 0, 0, 50);
        relativeLayout.addView(button, params);

        setContentView(relativeLayout);
    }

    public void goBack( View v )
    {
        this.finish( );
    }
}
